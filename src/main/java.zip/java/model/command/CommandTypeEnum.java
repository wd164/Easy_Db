/*
 *@Type CommandTypeEnum.java
 * @Desc
 * @Author urmsone urmsone@163.com
 * @date 2024/6/13 01:53
 * @version
 */
package model.command;

public enum CommandTypeEnum {
    /*
    * 增、改
    * */
    SET,
    /*
    * 删
    * */
    RM
}
